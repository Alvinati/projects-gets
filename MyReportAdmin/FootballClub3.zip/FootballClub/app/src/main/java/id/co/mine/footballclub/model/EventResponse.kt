package id.co.mine.footballclub.model

data class EventResponse(
            val events: List<Event>
    )
