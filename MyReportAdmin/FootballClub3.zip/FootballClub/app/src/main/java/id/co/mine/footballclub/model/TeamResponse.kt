package id.co.mine.footballclub.model

data class TeamResponse(
            val teams: List<Team>
    )
