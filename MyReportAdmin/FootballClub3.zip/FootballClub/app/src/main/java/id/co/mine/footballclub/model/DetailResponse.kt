package id.co.mine.footballclub.model

data class DetailResponse(
            val events: List<Detail>
    )
