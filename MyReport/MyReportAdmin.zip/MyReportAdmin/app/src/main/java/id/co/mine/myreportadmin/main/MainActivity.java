package id.co.mine.myreportadmin.main;


import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import id.co.mine.myreportadmin.R;
import id.co.mine.myreportadmin.fragments.NotifFragment;
import id.co.mine.myreportadmin.fragments.ReportFragment;
import id.co.mine.myreportadmin.fragments.UsersFragment;

public class MainActivity extends AppCompatActivity {

    String token;
    private ActionBar toolbar;
    boolean doubleClicktoExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        token = FirebaseInstanceId.getInstance().getToken();
        //Log.e("tokenId", token);

        toolbar = getSupportActionBar();
        toolbar.setTitle("Report");
        BottomNavigationView bottomNavigation = findViewById(R.id.navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(mOnNavigationItemReselectedListener);
        loadFragment(new ReportFragment());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_account:
                Toast.makeText(this, "Action Account Selected", Toast.LENGTH_LONG).show();
                break;
            case R.id.action_change_password:
                Toast.makeText(this, "Action Change password Selected", Toast.LENGTH_LONG).show();
                break;
            case R.id.action_logout:
                onLogout();
                break;
            default:
                break;
        }

        return true;
    }

    private void onLogout(){
        final AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
        alertDialog.setTitle("Loging Out App");
        alertDialog.setMessage("Are you sure want to logout?");
        alertDialog.setButton(DialogInterface.BUTTON_POSITIVE, "Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                alertDialog.dismiss();

                Intent toLogin = new Intent(MainActivity.this, LoginActivity.class);
                toLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                toLogin.putExtra("isLogedout", true);
                finish();
                startActivity(toLogin);
            }
        });

        alertDialog.show();

    }



    @Override
    public void onBackPressed() {
        if(doubleClicktoExitPressedOnce){
            super.onBackPressed();
            finish();
            return;
        }

        this.doubleClicktoExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_LONG).show();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleClicktoExitPressedOnce = false;
            }
        }, 2000);
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemReselectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.navigation_report:
                    toolbar.setTitle("Report");
                    fragment = new ReportFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_notif:
                    toolbar.setTitle("Notification");
                    fragment = new NotifFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.navigation_users:
                    toolbar.setTitle("Users");
                    fragment = new UsersFragment();
                    loadFragment(fragment);
                   return true;
            }
            return  false;
        }

    };

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}
