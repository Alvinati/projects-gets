package id.co.mine.myreportadmin.main;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NetworkError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.google.firebase.iid.FirebaseInstanceId;

import id.co.mine.myreportadmin.BuildConfig;
import id.co.mine.myreportadmin.R;
import id.co.mine.myreportadmin.dfactory.JSONParser;
import id.co.mine.myreportadmin.dfactory.SingletonRequestQueue;

public class LoginActivity extends AppCompatActivity {

    SharedPreferences.Editor editor;
    Context mContext;
    Activity mActivity;
    PopupWindow mPopupWindow;
    RelativeLayout loginView;
    TextView loginBtn;
    EditText etEmail, etPassword;
    ProgressBar pbLoading;
    String refreshedToken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        refreshedToken = FirebaseInstanceId.getInstance().getToken();
        Log.e( "Refreshed token: " , refreshedToken);

        mContext = getApplicationContext();
        mActivity = LoginActivity.this;
        pbLoading = findViewById(R.id.pb_login);
        pbLoading.setVisibility(View.GONE);

        etEmail = findViewById(R.id.login_et_email);
        etPassword = findViewById(R.id.login_et_password);

        SharedPreferences sharedPref = LoginActivity.this.getPreferences(Context.MODE_PRIVATE);
        editor = sharedPref.edit();

        Boolean isLogedout = getIntent().getBooleanExtra("isLogedout", false);
        Boolean isLogedin = sharedPref.getBoolean("isLogedin", false);

        if(isLogedout){
            editor.putBoolean("isLogedin", false);
            editor.apply();
        } else if(isLogedin){
            Intent directHome = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(directHome);
        }

        TextView buttonLogin = findViewById(R.id.btn_login);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();

                ConnectivityManager cm =
                        (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);

                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();

                Log.e("email", email);
                Log.e("password", password);
                if(email.equals("") || password.equals("")){
                    Toast.makeText(LoginActivity.this, "Mohon isi email dan password", Toast.LENGTH_SHORT).show();
                } else if(!isConnected){
                    Toast.makeText(LoginActivity.this, "No Network Available", Toast.LENGTH_SHORT).show();
                }
                else {
                    pbLoading.setVisibility(View.VISIBLE);
                    LoginRequest(email, password);

                }


            }
        });

    }

    Response.ErrorListener errorListener = new
            Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if(error instanceof NetworkError) {
                        Toast.makeText(getApplicationContext(), "No network available", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }
            };

    private void LoginRequest(String email, String password) {
        VolleyLog.DEBUG = true;
        RequestQueue queue = SingletonRequestQueue.getInstance(getApplicationContext()).getRequestQueue();
        String uri = BuildConfig.BASE_URL + "/api/authmain/tb_muser?email=" + email + "&password="
                                        + password + "&token=" + refreshedToken;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, uri, new Response.Listener<String>(){

            @Override
            public void onResponse(String response) {

                VolleyLog.wtf(response, "utf-8");

                new JSONParser.ParseJson(response);

                String[] loginData = JSONParser.dataLogin;

                if(loginData[0].equals("Ok")){

                    editor.putBoolean("isLogedin", true);
                    editor.commit();

                    Intent logedIn = new Intent(LoginActivity.this, MainActivity.class);
                    logedIn.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    logedIn.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(logedIn);
                    finish();

                } else {
                    Toast.makeText(LoginActivity.this, loginData[1], Toast.LENGTH_SHORT).show();
                }

                pbLoading.setVisibility(View.INVISIBLE);

                Log.e("LoginResponse", response);

            }
        }, errorListener) {
            @Override
            public Priority getPriority() {
                return Priority.LOW;
            }
        };
        queue.add(stringRequest);
    }
}
